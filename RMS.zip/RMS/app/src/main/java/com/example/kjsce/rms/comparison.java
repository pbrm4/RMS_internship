package com.example.kjsce.rms;

import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.ArrayMap;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import java.util.ArrayList;

import static com.example.kjsce.rms.R.id.pid;

public class comparison extends AppCompatActivity {
    private ProgressDialog pDialog;


    int width = Resources.getSystem().getDisplayMetrics().widthPixels;
    int height = Resources.getSystem().getDisplayMetrics().heightPixels;

    // Creating JSON Parser object
    JSONParser jParser = new JSONParser();
    JSONObject json,allstores;
    ArrayList<String> storename;
    ArrayList<String> searchequery;
    JSONArray products = null;
    JSONArray stores= null;
    ArrayList<String> fetchList;
    ArrayList<HashMap<String,String>> pricelist;
    ArrayMap<String,JSONArray> productlist;

    private static final String TAG_SUCCESS = "success";
    private static final String TAG_PRODUCTS = "products";
    private static final String TAG_PRICE = "price";

    String price="";
    int n;
    TextView pricetest;

    private static String url_all_products_prices = "https://rmsanp.000webhostapp.com/getalltypes.php";
    private static String url_all_stores = "https://rmsanp.000webhostapp.com/getallstores.php";


    TableLayout tl;
    TableRow tr;
    TextView retailname;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comparison);
        tl = (TableLayout) findViewById(R.id.maintable);

        fetchList= new ArrayList<String>();

        pricelist=new ArrayList<HashMap<String, String>>();
        fetchList=  getIntent().getStringArrayListExtra("productlist");

        ArrayList<HashMap<String, String>> arl = (ArrayList<HashMap<String, String>>) getIntent().getSerializableExtra("arraylist");

        n = fetchList.size();




        new GetProductDetails().execute();
        Log.d("After async: ","INSIDE HERE");
    }


    /////////////////////////////////////////////////////////////////////////////////////////////////////////
    /**
     * Background Async Task to Get complete product details
     * */
    class GetProductDetails extends AsyncTask<String, String, String> {

        /**
         * Before starting background thread Show Progress Dialog
         * */
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(comparison.this);
            pDialog.setMessage("Loading product details. Please wait...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
        }

        /**
         * Getting product details in background thread
         * */
        protected String doInBackground(String... param) {

            // updating UI from Background Thread

                    // Check for success tag
                    int success=1;
                    try {
                        // Building Parameters
                        List<NameValuePair> params = new ArrayList<NameValuePair>();

                         json = jParser.makeHttpRequest(url_all_products_prices, "GET", params);
                         allstores = jParser.makeHttpRequest(url_all_stores,"GET",params);
                        // check your log for json response
                        Log.d("Single Product Details", json.toString());
                        Log.d("ALl retail stores",allstores.toString());

                        // json success tag

                        if (success == 1) {
                            // successfully received product details
                            stores = allstores.getJSONArray("products");
                            storename = new ArrayList<String>();
                            for(int i=0;i<stores.length();i++){
                                JSONObject allstore = stores.getJSONObject(i);
                                String name = allstore.getString("retailname");
                                storename.add(name);
                            }
                            Log.d("ALL STRORES EXTRACT: ",storename.toString());

                            // get first product object from JSON Array

                            searchequery = new ArrayList<String>();
                            for(int i=0;i<fetchList.size();i++){
                                String productname = fetchList.get(i).toString();
                                for(int j=0;j<storename.size();j++){
                                    searchequery.add(productname+storename.get(j));
                                }
                            }

                            Log.d("Search query BROOOO!!",searchequery.toString());
                            products = json.getJSONArray("products"); // JSON Array
                            Log.d("lenght: ",Integer.toString(products.length()));
                            Log.d("lenghts2 ",Integer.toString(searchequery.size()));
                            JSONObject productroot = products.getJSONObject(products.length()-1);
                            Log.d("checking",productroot.toString());


                            productlist= new ArrayMap<String,JSONArray>();

                            for(int i=0;i<searchequery.size();i++){
                                JSONArray product = productroot.getJSONArray(searchequery.get(i));
                                JSONObject product1 = product.getJSONObject(0);
                                Log.d("Product root "+i+"  :" ,product.toString());
                                productlist.put(searchequery.get(i),product);
                            }

                            Log.d("Product root " ,productlist.toString());

                        }else{
                            // product with pid not found
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }


            return null;
        }

        /**
         * After completing background task Dismiss the progress dialog
         * **/
        protected void onPostExecute(String file_url) {
            // dismiss the dialog once got all details
            pDialog.dismiss();

            runOnUiThread(new Runnable() {
                public void run() {
                    /* setting headers for tables
                    */
                    tr = new TableRow(comparison.this);
                    tr.setLayoutParams(new TableRow.LayoutParams(
                            TableRow.LayoutParams.FILL_PARENT,
                            TableRow.LayoutParams.WRAP_CONTENT));
                   for(int i=0;i<storename.size();i++){

                       TextView companyName = new TextView(comparison.this);
                       companyName.setText(storename.get(i));
                       companyName.setTextColor(Color.RED);
                      // companyName.setPadding(15, 15, 15, 0);
                       companyName.setTextSize(15);
                       companyName.setMinWidth(width/(storename.size()));
                       companyName.setMinHeight(25);
                       companyName.setGravity(Gravity.CENTER);
                       companyName.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
                       tr.addView(companyName);
                   }
                    tl.addView(tr, new TableLayout.LayoutParams(
                            TableLayout.LayoutParams.FILL_PARENT,
                            TableLayout.LayoutParams.WRAP_CONTENT));



                    for(int j=0;j<fetchList.size();j++) {
                        tr = new TableRow(comparison.this);
                        tr.setLayoutParams(new TableRow.LayoutParams(
                                TableRow.LayoutParams.FILL_PARENT,
                                TableRow.LayoutParams.WRAP_CONTENT));


                        for (int i = 0; i < storename.size(); i++) {
                            TextView tv = new TextView(comparison.this);
                            String toprint = fetchList.get(j)+"\n";
                            String quer = fetchList.get(j)+storename.get(i);

                            String textmeikyahai = productlist.get(quer)/*.get(0)*/.toString();
                            Log.d("checkmystring ",textmeikyahai);
                            String textmeikyahai2="";

                            try {
                                textmeikyahai2 = productlist.get(quer).getJSONObject(0).getString("price");

                                Log.d("checkmystring21212121 ",textmeikyahai2);
                            }
                            catch(JSONException e){
                                Log.d("JSON E","JSON error primtng stack next");
                                e.printStackTrace();
                            }
                            toprint = toprint+textmeikyahai2;
                            tv.setText(toprint);
                            tv.setTextColor(Color.RED);
                            tv.setTextSize(15);
                            tv.setMinWidth(width/(storename.size()));
                            tv.setMinHeight(25);
                            tv.setGravity(Gravity.CENTER);
                            tv.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
                            tr.addView(tv);

                        }
                        tl.addView(tr, new TableLayout.LayoutParams(
                                TableLayout.LayoutParams.FILL_PARENT,
                                TableLayout.LayoutParams.WRAP_CONTENT));

                    }
                }


            });
        }
    }

    //////////////////////////////////////////////////////////////////////////////////////////////////////////
}
