package com.example.kjsce.rms;

import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class products extends ListActivity {
    private ProgressDialog pDialog;

    // Creating JSON Parser object
    JSONParser jParser = new JSONParser();

    ArrayList<HashMap<String, String>> productsList;
    ArrayList<HashMap<String, String>> productsListprices;
    ArrayList<String>productname;
    ArrayList<String>arr;

    private TextView cart;
    private Button cartNext;
    private EditText searcher;
    private ListView lv;
    ArrayAdapter<String> adapter;

    private static String url_all_products = "https://rmsanp.000webhostapp.com/getprod.php";
    private static String url_all_products_types = "https://rmsanp.000webhostapp.com/getalltypes.php";
    // JSON Node names
    private static final String TAG_SUCCESS = "success";
    private static final String TAG_PRODUCTS = "products";
    private static final String TAG_ID = "id";
    private static final String TAG_PNAME = "productname";

    // products JSONArray
    JSONArray products = null;
    JSONArray productprices = null;

    // url to get all products list

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_products);


        Log.d("GOT FROM INTENT: ",getIntent().getStringExtra("placeName"));

        productsList = new ArrayList<HashMap<String, String>>();
        productname = new ArrayList<String>();
        cart = (TextView)findViewById(R.id.cartCount);
        cartNext = (Button)findViewById(R.id.cartButton);
        searcher = (EditText)findViewById(R.id.search_product);
        // Loading products in Background Thread
        new LoadAllProducts().execute();

         lv = getListView();
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                // getting values from selected ListItem

                String pid = ((TextView) view.findViewById(R.id.name)).getText().toString();
                Log.d("testbug101", productname.toString());
                if(productname.contains(pid)){
                    productname.remove(pid);
                    ((TextView)view.findViewById(R.id.name)).setBackgroundColor(getResources().getColor(R.color.white));
                }
                else {
                    productname.add(pid);
                    ((TextView)view.findViewById(R.id.name)).setBackgroundColor(getResources().getColor(R.color.navigationBarColor));
                }
                Log.d("testbug102", productname.toString());

                cart.setText(Integer.toString(productname.size()));
            }
        });
        searcher.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                products.this.adapter.getFilter().filter(s);


            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        cartNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gotonext = new Intent(products.this,comparison.class);
                gotonext.putExtra("prices",productsListprices);
                gotonext.putStringArrayListExtra("productlist",productname);

                startActivity(gotonext);
            }
        });

    }

    // Response from Edit Product Activity
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // if result code 100
        if (resultCode == 100) {
            // if result code 100 is received
            // means user edited/deleted product
            // reload this screen again
            Intent intent = getIntent();
            finish();
            startActivity(intent);
            Log.d("Activity Result","IN HERE BRO");
        }

    }
/////////////////////////////////////////////////////////////////////////////////////////////
class LoadAllProducts extends AsyncTask<String, String, String> {

    /**
     * Before starting background thread Show Progress Dialog
     * */
    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        pDialog = new ProgressDialog(products.this);
        pDialog.setMessage("Loading products. Please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(false);
        pDialog.show();
    }

    /**
     * getting All products from url
     * */
    protected String doInBackground(String... args) {
        // Building Parameters
        List<NameValuePair> params = new ArrayList<NameValuePair>();
        // getting JSON string from URL
        JSONObject json = jParser.makeHttpRequest(url_all_products, "GET", params);
        JSONObject jsonall = jParser.makeHttpRequest(url_all_products_types,"GET",params);
        // Check your log cat for JSON reponse
        Log.d("All Products: ", json.toString());
        Log.d("All products types",jsonall.toString());

        try {
            // Checking for SUCCESS TAG
           int success =1;

            if (success == 1) {
                // products found
                // Getting Array of Products
                products = json.getJSONArray(TAG_PRODUCTS);
                productprices =json.getJSONArray(TAG_PRODUCTS);
                // looping through All Products
                //
                for (int i = 0; i < products.length(); i++) {
                    JSONObject c = products.getJSONObject(i);
                    // Storing each json item in variable
                   // String id = c.getString(TAG_ID);
                    String name = c.getString(TAG_PNAME);
                    // creating new HashMap

                    HashMap<String,String> map = new HashMap<String, String>();
                    // adding each child node to HashMap key => value
                   // map.put(TAG_ID, id);

                    map.put(TAG_PNAME, name);
                    // adding HashList to ArrayList
                    productsList.add(map);
                    //arr.add(productsList.get(i).toString());
                }

/*
                for(int i=0;i<productprices.length();i++){
                    JSONObject c = productprices.getJSONObject(i);
                    // Storing each json item in variable
                    // String id = c.getString(TAG_ID);
                    String name = c.getString(TAG_PNAME);
                    String price = c.getString("price");
                    String retailname = c.getString("retailname");
                    // creating new HashMap

                    HashMap<String,String> map = new HashMap<String, String>();
                    // adding each child node to HashMap key => value
                    // map.put(TAG_ID, id);

                    map.put(TAG_PNAME, name);
                    map.put("price",price);
                    map.put("retailname",retailname);
                    // adding HashList to ArrayList
                    productsListprices.add(map);
                    //arr.add(productsList.get(i).toString());
                }*/
            } else {

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return null;
    }

    /**
     * After completing background task Dismiss the progress dialog
     * **/

    protected void onPostExecute(String file_url) {
        // dismiss the dialog after getting all products
        pDialog.dismiss();
        // updating UI from Background Thread
        runOnUiThread(new Runnable() {
            public void run() {
                /**
                 * Updating parsed JSON data into ListView
                 * */
                arr = new ArrayList<String>();
                for(int i=0;i<productsList.size();i++){

                    arr.add(productsList.get(i).get(TAG_PNAME));
                }
                Log.d("ARRRR: ",Integer.toString(arr.size()));
                adapter = new ArrayAdapter<String>(products.this,R.layout.list_item,R.id.name,arr);

                setListAdapter(adapter);
            }
        });

    }

}





//////////////////////////////////////////////////////////////////////////////////////////////
}


